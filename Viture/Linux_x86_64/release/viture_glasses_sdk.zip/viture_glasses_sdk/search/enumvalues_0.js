var searchData=
[
  ['xr_5fdevice_5ftype_5fviture_5fcarina_114',['XR_DEVICE_TYPE_VITURE_CARINA',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea1231a632c9a7b53c9b1d384d57ae2590',1,'viture_glasses_provider.h']]],
  ['xr_5fdevice_5ftype_5fviture_5fgen1_115',['XR_DEVICE_TYPE_VITURE_GEN1',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0551526d67deed27f08de249e886ae09',1,'viture_glasses_provider.h']]],
  ['xr_5fdevice_5ftype_5fviture_5fgen2_116',['XR_DEVICE_TYPE_VITURE_GEN2',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3ea0e4ccea9e04cf2c1af3f0948dd074c2d',1,'viture_glasses_provider.h']]]
];
