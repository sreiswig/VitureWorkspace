var searchData=
[
  ['xrdevicetype_113',['XRDeviceType',['../viture__glasses__provider_8h.html#a8b6902060fcc59dd61000fe24de22b3e',1,'viture_glasses_provider.h']]]
];
