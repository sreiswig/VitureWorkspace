var searchData=
[
  ['glassstatecallback_0',['GlassStateCallback',['../viture__glasses__provider_8h.html#a2ea8b0f6cf78fed4b748b4abb93a4902',1,'viture_glasses_provider.h']]]
];
