var searchData=
[
  ['loghook_1',['LogHook',['../viture__glasses__provider_8h.html#ab20aa4cf7e7fd746db0747fa139abe5e',1,'viture_glasses_provider.h']]]
];
