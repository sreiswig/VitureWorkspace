var viture__protocol__public_8h =
[
    [ "XRDeviceProviderHandle", "viture__protocol__public_8h.html#a673cef8049a5e15343c066644d99fb8c", null ],
    [ "xr_device_provider_get_brightness_level", "viture__protocol__public_8h.html#af17873e102a25af9965c85367ab285a5", null ],
    [ "xr_device_provider_get_display_distance", "viture__protocol__public_8h.html#af20963f1f69039f22797e10b8c9fb200", null ],
    [ "xr_device_provider_get_display_mode", "viture__protocol__public_8h.html#a5f2c3eae6b8be1f410f570bee43e17eb", null ],
    [ "xr_device_provider_get_display_mode_and_native_dof", "viture__protocol__public_8h.html#af00664b69b32fdf81e04cbd4688b58eb", null ],
    [ "xr_device_provider_get_display_size", "viture__protocol__public_8h.html#a7e3e682acc0d7d2a7f1fac99c930b823", null ],
    [ "xr_device_provider_get_duty_cycle", "viture__protocol__public_8h.html#a272e8af1ab1a9a20762de6c227c81155", null ],
    [ "xr_device_provider_get_film_mode", "viture__protocol__public_8h.html#a8cfe64b0f3ab4328caadfae463317baf", null ],
    [ "xr_device_provider_get_glasses_version", "viture__protocol__public_8h.html#a168a3b65854afca52ede3ec8aeae31e5", null ],
    [ "xr_device_provider_get_volume_level", "viture__protocol__public_8h.html#adbf708962447b2cfe7c02c544942b4dd", null ],
    [ "xr_device_provider_native_dof_recenter", "viture__protocol__public_8h.html#a2638563f3970c216140353983778c673", null ],
    [ "xr_device_provider_set_brightness_level", "viture__protocol__public_8h.html#af6b3e4bb025ff24503ef9f4d63582df8", null ],
    [ "xr_device_provider_set_display_distance", "viture__protocol__public_8h.html#a73e6b4fe7b55cbeedb94a41104580567", null ],
    [ "xr_device_provider_set_display_mode", "viture__protocol__public_8h.html#ad79ce8735729b9d492716bdade5b8060", null ],
    [ "xr_device_provider_set_display_mode_and_native_dof", "viture__protocol__public_8h.html#a1adfec49c7a2068f4056cdb739b8f843", null ],
    [ "xr_device_provider_set_display_size", "viture__protocol__public_8h.html#a741ce0b052241b1473dea3e97dca72e3", null ],
    [ "xr_device_provider_set_duty_cycle", "viture__protocol__public_8h.html#a5a3b204301fc77d2a73bc7be560ee8b9", null ],
    [ "xr_device_provider_set_film_mode", "viture__protocol__public_8h.html#a814cd71e2dcd1d9d0b4668077a933d95", null ],
    [ "xr_device_provider_set_volume_level", "viture__protocol__public_8h.html#a7804168b7caefef58c7230c96120d115", null ],
    [ "xr_device_provider_switch_dimension", "viture__protocol__public_8h.html#af10a19540de632264aaa6bbe59f65020", null ]
];