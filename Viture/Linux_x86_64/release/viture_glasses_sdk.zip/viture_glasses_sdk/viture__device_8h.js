var viture__device_8h =
[
    [ "VitureImuPoseCallback", "viture__device_8h.html#a31ae90b9c675c795063772a9a5fad7a7", null ],
    [ "VitureImuRawCallback", "viture__device_8h.html#a810a4b44f8b9450ab0d52f7cf88b8f07", null ],
    [ "xr_device_provider_close_imu", "viture__device_8h.html#a6d56fc15943d12c55f062a86e211d321", null ],
    [ "xr_device_provider_open_imu", "viture__device_8h.html#a29abbc6aff9731ee6046cd596c49500e", null ],
    [ "xr_device_provider_register_imu_pose_callback", "viture__device_8h.html#a9e9a831bb9b06ed063779594fc77912c", null ],
    [ "xr_device_provider_register_imu_raw_callback", "viture__device_8h.html#a0e4fca7cb1b07ce9be4303e26a106c44", null ]
];