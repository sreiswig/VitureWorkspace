namespace Viture.XR
{
    public static class VitureConstants
    {
        public const string k_SettingsKey = "com.viture.xr.settings";

        public const string k_DefaultSdkVersion = "0.5.0";
        
        public const string k_MinimumOSVersion = "0.1.0";
    }
}
